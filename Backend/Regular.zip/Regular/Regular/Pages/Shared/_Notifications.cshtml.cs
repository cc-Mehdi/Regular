using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Regular.Pages.Shared
{
    public class _NotificationsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
