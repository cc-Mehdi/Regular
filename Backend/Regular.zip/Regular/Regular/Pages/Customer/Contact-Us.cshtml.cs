using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Regular.Pages.Customer
{
    public class Contact_UsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
