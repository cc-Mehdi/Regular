using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Regular.Pages.Customer
{
    public class About_UsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
